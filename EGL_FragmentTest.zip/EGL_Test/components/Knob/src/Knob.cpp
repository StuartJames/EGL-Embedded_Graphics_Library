/*
 *              LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include "Knob.h"

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[Knob  ]";

/////////////////////////////////////////////////////////////////////////////////////

ESPQuadKnob          *ESPQuadKnob::m_pListHead = NULL;
bool                  ESPQuadKnob::m_InterruptServiceInstalled = false;
bool                  ESPQuadKnob::m_TimerIsRunning = false;
esp_timer_handle_t    ESPQuadKnob::m_hTimer = NULL;

/////////////////////////////////////////////////////////////////////////////////////

static void TimerCB(void *args)
{
ESPQuadKnob *pKnob;
bool EnterPowerSaveFlag = true;

	for(pKnob = ESPQuadKnob::m_pListHead; pKnob; pKnob = pKnob->m_pNext) {
		pKnob->EventHandler();
		if(!(pKnob->m_PowerSave && pKnob->m_DebounceCountA == 0 && pKnob->m_DebounceCountB == 0 && pKnob->m_Event == KNOB_NONE)) {
			EnterPowerSaveFlag = false;
		}
	}
	if(EnterPowerSaveFlag) {		// Stop esp timer for power save 
		if(ESPQuadKnob::m_TimerIsRunning) {
			esp_timer_stop(ESPQuadKnob::m_hTimer);
			ESPQuadKnob::m_TimerIsRunning = false;
		}
		for(pKnob = ESPQuadKnob::m_pListHead; pKnob; pKnob = pKnob->m_pNext) {
			if(pKnob->m_PowerSave) {
				knob_gpio_wake_up_control(pKnob->m_PhasePinA, !pKnob->m_PhaseLevelA, true);
				knob_gpio_wake_up_control(pKnob->m_PhasePinB, !pKnob->m_PhaseLevelB, true);
				knob_gpio_set_intr(pKnob->m_PhasePinA, !(pKnob->m_PhaseLevelA == 0) ? GPIO_INTR_LOW_LEVEL : GPIO_INTR_HIGH_LEVEL);
				knob_gpio_set_intr(pKnob->m_PhasePinB, !(pKnob->m_PhaseLevelB == 0) ? GPIO_INTR_LOW_LEVEL : GPIO_INTR_HIGH_LEVEL);
				knob_gpio_intr_control(pKnob->m_PhasePinA, true);
				knob_gpio_intr_control(pKnob->m_PhasePinB, true);
			}
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////////

static void IRAM_ATTR WakeupISRHandler(void *arg)
{
	if(!ESPQuadKnob::m_TimerIsRunning){
		esp_timer_start_periodic(ESPQuadKnob::m_hTimer, TICKS_INTERVAL * 1000U);
		ESPQuadKnob::m_TimerIsRunning = true;
	}
	knob_gpio_intr_control(*((gpio_num_t*)arg), false);
	knob_gpio_wake_up_control(*((gpio_num_t*)arg), 0, false);	// disable gpio wake up not need wake up level
}

/////////////////////////////////////////////////////////////////////////////////////

ESPQuadKnob::ESPQuadKnob(void)
{
}

/////////////////////////////////////////////////////////////////////////////////////

ESPQuadKnob::~ESPQuadKnob()
{
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPQuadKnob::Create(const KnobConfig_t *pConfig)
{
esp_err_t ret = ESP_OK;

	ret = knob_gpio_init(pConfig->PhasePinA);
	KNOB_CHECK_GOTO(ret == ESP_OK, "encoder A gpio init failed", _encoder_deinit);
	ret = knob_gpio_init(pConfig->PhasePinB);
	KNOB_CHECK_GOTO(ret = ESP_OK, "encoder B gpio init failed", _encoder_deinit);
	m_PhaseDirection = pConfig->PhaseDirection;
	m_PhasePinA = pConfig->PhasePinA;
	m_PhasePinB = pConfig->PhasePinB;
	m_PhaseLevelA = GetKeyLevel(m_PhasePinA);
	m_PhaseLevelB = GetKeyLevel(m_PhasePinB);
	if(pConfig->PowerSave) {
		m_PowerSave = pConfig->PowerSave;
		knob_gpio_init_intr(pConfig->PhasePinA, !(m_PhaseLevelA == 0) ? GPIO_INTR_LOW_LEVEL : GPIO_INTR_HIGH_LEVEL, WakeupISRHandler, (void*)&m_PhasePinA);
		knob_gpio_init_intr(pConfig->PhasePinB, !(m_PhaseLevelB == 0) ? GPIO_INTR_LOW_LEVEL : GPIO_INTR_HIGH_LEVEL, WakeupISRHandler, (void*)&m_PhasePinB);
		ret = knob_gpio_wake_up_init(pConfig->PhasePinA, !m_PhaseLevelA);
		KNOB_CHECK_GOTO((ret == ESP_OK), "encoder A wake up gpio init failed", _encoder_deinit);
		ret = knob_gpio_wake_up_init(pConfig->PhasePinB, !m_PhaseLevelB);
		KNOB_CHECK_GOTO((ret == ESP_OK), "encoder B wake up gpio init failed", _encoder_deinit);
	}
	m_State = KNOB_CHECK;
	m_Event = KNOB_NONE;
	m_pNext = m_pListHead;
	m_pListHead = this;
	if(!m_hTimer) {
		esp_timer_create_args_t knob_timer = {};
		knob_timer.arg = NULL;
		knob_timer.callback = TimerCB;
		knob_timer.dispatch_method = ESP_TIMER_TASK;
		knob_timer.name = "knob_timer";
		esp_timer_create(&knob_timer, &m_hTimer);
	}
	if(!m_PowerSave && !m_TimerIsRunning) {
		esp_timer_start_periodic(m_hTimer, TICKS_INTERVAL * 1000U);
		m_TimerIsRunning = true;
	}
	return ESP_OK;

_encoder_deinit:
	knob_gpio_deinit(pConfig->PhasePinA);
	knob_gpio_deinit(pConfig->PhasePinB);
	return ESP_FAIL;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPQuadKnob::RegisterCB( knob_event_t Event, knob_cb_t Callback, void *pUserData)
{
	KNOB_CHECK(Event < KNOB_EVENT_MAX, "Event is invalid", ESP_ERR_INVALID_ARG);
	m_CallBacks[Event] = Callback;
	m_pUserData[Event] = pUserData;
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPQuadKnob::UnregisterCB(knob_event_t Event)
{
	KNOB_CHECK(Event < KNOB_EVENT_MAX, "Event is invalid", ESP_ERR_INVALID_ARG);
	m_CallBacks[Event] = NULL;
	m_pUserData[Event] = NULL;
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

void ESPQuadKnob::EventHandler(void)
{
	uint8_t pha_value = GetKeyLevel(m_PhasePinA);
	uint8_t phb_value = GetKeyLevel(m_PhasePinB);
	if((m_State) > 0) {
		m_Ticks++;
	}
	if(pha_value != m_PhaseLevelA) {
		if(++(m_DebounceCountA) >= DEBOUNCE_TICKS) {
			m_PhaseChangeA = true;
			m_PhaseLevelA = pha_value;
			m_DebounceCountA = 0;
		}
	}
	else {
		m_DebounceCountA = 0;
	}
	if(phb_value != m_PhaseLevelB) {
		if(++(m_DebounceCountB) >= DEBOUNCE_TICKS) {
			m_PhaseChangeB = true;
			m_PhaseLevelB = phb_value;
			m_DebounceCountB = 0;
		}
	}
	else {
		m_DebounceCountB = 0;
	}
	switch(m_State) {
		case KNOB_READY:{
			if(m_PhaseChangeA) {
				m_PhaseChangeA = false;
				m_Ticks = 0;
				m_State = KNOB_PHASE_A;
			}
			else if(m_PhaseChangeB) {
				m_PhaseChangeB = false;
				m_Ticks = 0;
				m_State = KNOB_PHASE_B;
			}
			else {
				m_Event = KNOB_NONE;
			}
			break;
    }
		case KNOB_PHASE_A:{
			if(m_PhaseChangeB) {
				m_PhaseChangeB = false;
				if(m_PhaseDirection) {
					m_PhaseChangeCount--;
					m_Event = KNOB_LEFT;
					CallEventCB(KNOB_LEFT);
					if(m_PhaseChangeCount <= LOW_LIMIT) {
						m_Event = KNOB_L_LIM;
						CallEventCB(KNOB_L_LIM);
						m_PhaseChangeCount = 0;
					}
					else if(m_PhaseChangeCount == 0) {
						m_Event = KNOB_ZERO;
						CallEventCB(KNOB_ZERO);
					}
				}
				else {
					m_PhaseChangeCount++;
					m_Event = KNOB_RIGHT;
					CallEventCB(KNOB_RIGHT);
					if(m_PhaseChangeCount >= HIGH_LIMIT) {
						m_Event = KNOB_H_LIM;
						CallEventCB(KNOB_H_LIM);
						m_PhaseChangeCount = 0;
					}
					else if(m_PhaseChangeCount == 0) {
						m_Event = KNOB_ZERO;
						CallEventCB(KNOB_ZERO);
					}
				}
				m_Ticks = 0;
				m_State = KNOB_READY;
			}
			else if(m_PhaseChangeA) {
				m_PhaseChangeA = false;
				m_Ticks = 0;
				m_State = KNOB_READY;
			}
			else {
				m_Event = KNOB_NONE;
			}
			break;
    }
		case KNOB_PHASE_B:{
			if(m_PhaseChangeA) {
				m_PhaseChangeA = false;
				if(m_PhaseDirection) {
					m_PhaseChangeCount++;
					m_Event = KNOB_RIGHT;
					CallEventCB(KNOB_RIGHT);
					if(m_PhaseChangeCount >= HIGH_LIMIT) {
						m_Event = KNOB_H_LIM;
						CallEventCB(KNOB_H_LIM);
						m_PhaseChangeCount = 0;
					}
					else if(m_PhaseChangeCount == 0) {
						m_Event = KNOB_ZERO;
						CallEventCB(KNOB_ZERO);
					}
				}
				else {
					m_PhaseChangeCount--;
					m_Event = KNOB_LEFT;
					CallEventCB(KNOB_LEFT);
					if(m_PhaseChangeCount <= LOW_LIMIT) {
						m_Event = KNOB_L_LIM;
						CallEventCB(KNOB_L_LIM);
						m_PhaseChangeCount = 0;
					}
					else if(m_PhaseChangeCount == 0) {
						m_Event = KNOB_ZERO;
						CallEventCB(KNOB_ZERO);
					}
				}
				m_Ticks = 0;
				m_State = KNOB_READY;
			}
			else if(m_PhaseChangeB) {
				m_PhaseChangeB = false;
				m_Ticks = 0;
				m_State = KNOB_READY;
			}
			else {
				m_Event = KNOB_NONE;
			}
			break;
    }
		case KNOB_CHECK:{
			if(m_PhaseLevelA == m_PhaseLevelB) {
				m_State = KNOB_READY;
				m_PhaseChangeA = false;
				m_PhaseChangeB = false;
			}
			else {
				m_Event = KNOB_NONE;
			}
			break;
    }
	}
}

/////////////////////////////////////////////////////////////////////////////////////

knob_event_t ESPQuadKnob::GetEvent(void)
{
	return m_Event;
}

/////////////////////////////////////////////////////////////////////////////////////

int ESPQuadKnob::GetCountValue(void)
{
	return m_PhaseChangeCount;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPQuadKnob::ClearCountValue(void)
{
	m_PhaseChangeCount = 0;
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPQuadKnob::Resume(void)
{
	KNOB_CHECK(m_hTimer, "knob timer handle is invalid", ESP_ERR_INVALID_STATE);
	KNOB_CHECK(!m_TimerIsRunning, "knob timer is already running", ESP_ERR_INVALID_STATE);
	esp_err_t err = esp_timer_start_periodic(m_hTimer, TICKS_INTERVAL * 1000U);
	KNOB_CHECK(ESP_OK == err, "knob timer start failed", ESP_FAIL);
	m_TimerIsRunning = true;
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPQuadKnob::Stop(void)
{
	KNOB_CHECK(m_hTimer, "knob timer handle is invalid", ESP_ERR_INVALID_STATE);
	KNOB_CHECK(m_TimerIsRunning, "knob timer is not running", ESP_ERR_INVALID_STATE);
	esp_err_t err = esp_timer_stop(m_hTimer);
	KNOB_CHECK(ESP_OK == err, "knob timer stop failed", ESP_FAIL);
	m_TimerIsRunning = false;
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

ESPQuadKnob* NewQuadKnob(const KnobConfig_t *pConfig)
{
  KNOB_CHECK(pConfig != NULL, "Config pointer can't be null!", NULL)
	KNOB_CHECK(pConfig->PhasePinA != pConfig->PhasePinB, "Phase pin A can't be the same as phase pin B", NULL);
	ESPQuadKnob *pKnob = new ESPQuadKnob;
	KNOB_CHECK((pKnob == NULL), "new Knob failed", NULL);
	return pKnob;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t DeleteQuadKnob(ESPQuadKnob *pKnob)
{
esp_err_t ret = ESP_OK;

	KNOB_CHECK(pKnob != NULL, "Pointer to control is invalid", ESP_ERR_INVALID_ARG);
	ret = knob_gpio_deinit(*((gpio_num_t*)pKnob->m_pUserData));
	KNOB_CHECK(ESP_OK == ret, "Control deinitialise failed", ESP_FAIL);
	ESPQuadKnob **pList;
	for(pList = &ESPQuadKnob::m_pListHead; *pList;){
		ESPQuadKnob *pEntry = *pList;
		if(pEntry == pKnob) {
			*pList = pEntry->m_pNext;
			delete pEntry;
		}
		else {
			pList = &pEntry->m_pNext;
		}
	}
  pKnob = NULL; // control pointer not valid anymore
	uint16_t Number = 0;
	ESPQuadKnob *pHead = ESPQuadKnob::m_pListHead;
	while(pHead){           // re-link
		pHead = pHead->m_pNext;
		Number++;
	}
	ESP_LOGD(_TAG, "remain knob number=%d", Number);
	if(0 == Number && ESPQuadKnob::m_TimerIsRunning) { //  if all knobs are deleted, stop the timer 
		esp_timer_stop(ESPQuadKnob::m_hTimer);
		esp_timer_delete(ESPQuadKnob::m_hTimer);
		ESPQuadKnob::m_TimerIsRunning = false;
	}
	return ESP_OK;
}


