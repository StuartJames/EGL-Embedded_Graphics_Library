/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * This file contains code to implement the core start up code.
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original WeatherClock
 *
 */

 #include "BatteryDriver.h"

/////////////////////////////////////////////////////////////////////////////////////

Battery::Battery()
{
	m_Channel = ADC_CHANNEL_0;
	m_ScaledVoltage = 0;
}

/////////////////////////////////////////////////////////////////////////////////////

void Battery::Initialise(adc_channel_t Channel, adc_atten_t Atten)
{
adc_oneshot_unit_init_cfg_t init_config1{
	.unit_id = ADC_UNIT_1,
	.clk_src = ADC_RTC_CLK_SRC_DEFAULT,
	.ulp_mode = ADC_ULP_MODE_DISABLE 
};
adc_oneshot_chan_cfg_t config = {
	.atten = Atten,
	.bitwidth = ADC_BITWIDTH_DEFAULT
};

	m_Channel = Channel;
	ESP_ERROR_CHECK(adc_oneshot_new_unit(&init_config1, &m_hADC1OneShot));
	ESP_ERROR_CHECK(adc_oneshot_config_channel(m_hADC1OneShot, Channel, &config));
	m_DoCalibration = ADCCalibrationInit(ADC_UNIT_1, Channel, Atten, &m_hADC1Calibration);
// 	//Tear Down
// 	ESP_ERROR_CHECK(adc_oneshot_del_unit(adc1_handle));
// 	if(do_calibration1_chan3) example_adc_calibration_deinit(adc1_cali_chan3_handle);
}

/////////////////////////////////////////////////////////////////////////////////////

bool Battery::ADCCalibrationInit(adc_unit_t unit, adc_channel_t channel, adc_atten_t atten, adc_cali_handle_t *pHandle)
{
adc_cali_handle_t hCalibration = NULL;
esp_err_t Ret = ESP_FAIL;
bool Calibrated = false;

#if ADC_CALI_SCHEME_CURVE_FITTING_SUPPORTED
	if(!Calibrated) {
		ESP_LOGI(_TAG, "calibration scheme version is %s", "Curve Fitting");
		adc_cali_curve_fitting_config_t cali_config = {
			.unit_id = unit,
			.chan = channel,
			.atten = atten,
			.bitwidth = ADC_BITWIDTH_DEFAULT,
		};
		Ret = adc_cali_create_scheme_curve_fitting(&cali_config, &hCalibration);
		if(Ret == ESP_OK) {
			Calibrated = true;
		}
	}
#endif
#if ADC_CALI_SCHEME_LINE_FITTING_SUPPORTED
	if(!Calibrated) {
		ESP_LOGI(ADC_TAG, "calibration scheme version is %s", "Line Fitting");
		adc_cali_line_fitting_config_t cali_config = {
			.unit_id = unit,
			.atten = atten,
			.bitwidth = ADC_BITWIDTH_DEFAULT,
		};
		ret = adc_cali_create_scheme_line_fitting(&cali_config, &hCalibration);
		if(ret == ESP_OK) {
			Calibrated = true;
		}
	}
#endif
	*pHandle = hCalibration;
	if(Ret == ESP_OK) {
		ESP_LOGI(_TAG, "Calibration Success");
	}
	else if(Ret == ESP_ERR_NOT_SUPPORTED || !Calibrated) {
		ESP_LOGW(_TAG, "eFuse not burnt, skip software calibration");
	}
	else {
		ESP_LOGE(_TAG, "Invalid arg or no memory");
	}
	return Calibrated;
}

/////////////////////////////////////////////////////////////////////////////////////

float Battery::Read(void)
{
	adc_oneshot_read(m_hADC1OneShot, m_Channel, &m_RawADC[0][0]);
	// printf( "ADC%d Channel[%d] Raw Data: %d\r\n", ADC_UNIT_1 + 1, EXAMPLE_ADC1_CHAN, adc_raw[0][0]);
	if(m_DoCalibration) {
		ESP_ERROR_CHECK(adc_cali_raw_to_voltage(m_hADC1Calibration, m_RawADC[0][0], &m_Voltage[0][0]));
		// printf("ADC%d Channel[%d] Cali Voltage: %d mV\r\n", ADC_UNIT_1 + 1, EXAMPLE_ADC1_CHAN, voltage[0][0]);
		m_ScaledVoltage = (float)(m_Voltage[0][0] * 3.0 / 1000.0) / Measurementoffset_c;
		// printf("BAT voltage : %.2f V\r\n", BAT_analogVolts);
	}
	return m_ScaledVoltage;
}