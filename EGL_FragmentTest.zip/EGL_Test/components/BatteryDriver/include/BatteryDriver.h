/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * This file contains code to implement the core start up code.
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original WeatherClock
 *
 */

 #pragma once

#include <esp_log.h>
#include <esp_adc/adc_oneshot.h>
#include <esp_adc/adc_cali.h>
#include <esp_adc/adc_cali_scheme.h>

/////////////////////////////////////////////////////////////////////////////////////

const float Measurementoffset_c = 0.994500;

/////////////////////////////////////////////////////////////////////////////////////

class Battery
{
public:
							Battery();
	void 				Initialise(adc_channel_t Channel, adc_atten_t Atten);
	float 			Read(void);
	float 			GetVolts(void){ return m_ScaledVoltage; };

private:
	bool 				ADCCalibrationInit(adc_unit_t unit, adc_channel_t channel, adc_atten_t atten, adc_cali_handle_t *pHandle);
//	void 		ADCCalibrationDeinit(adc_cali_handle_t Handle);
	float 										m_ScaledVoltage = 0;
	adc_oneshot_unit_handle_t m_hADC1OneShot;
	adc_cali_handle_t 				m_hADC1Calibration = NULL;
	adc_channel_t							m_Channel;
	int 											m_RawADC[2][10];
	int 											m_Voltage[2][10];
	bool 											m_DoCalibration;

	const char *_TAG = "[ADC   ]";
};