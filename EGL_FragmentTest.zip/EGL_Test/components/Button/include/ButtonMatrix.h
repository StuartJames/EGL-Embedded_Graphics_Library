/*
 *              LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#pragma once

#include "esp_err.h"
#include "Button.h"

/* Button matrix key configuration.
 *        Just need to configure the GPIO associated with this GPIO in the matrix keyboard.
 *
 *        Matrix Keyboard Layout (3x3):
 *        ----------------------------------------
 *        |  Button 1  |  Button 2  |  Button 3  |
 *        |  (R1-C1)   |  (R1-C2)   |  (R1-C3)   |
 *        |--------------------------------------|
 *        |  Button 4  |  Button 5  |  Button 6  |
 *        |  (R2-C1)   |  (R2-C2)   |  (R2-C3)   |
 *        |--------------------------------------|
 *        |  Button 7  |  Button 8  |  Button 9  |
 *        |  (R3-C1)   |  (R3-C2)   |  (R3-C3)   |
 *        ----------------------------------------
 *
 *        - Button matrix key is driven using row scanning.
 *        - Buttons within the same column cannot be detected simultaneously,
 *          but buttons within the same row can be detected without conflicts. */


typedef struct {
    gpio_num_t    *pRowList;    
    gpio_num_t    *pColumnList; 
    int           RowCount;     
    int           ColumnCount;  
} ButtonMatrixConfig_t;

class ButtonMatrix;

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t NewMatrix(const ButtonConfig_t *pConfig, const ButtonMatrixConfig_t *pMatrixConfig, ButtonMatrix *pMatrix, size_t *pSize);

/////////////////////////////////////////////////////////////////////////////////////

class ButtonMatrix
{
public:
                      ButtonMatrix(void);
  virtual             ~ButtonMatrix();
  esp_err_t           Create(const ButtonConfig_t *pConfig, const ButtonMatrixConfig_t *pMatrixConfig, size_t *pSize);
  uint8_t             GetKeyLevel(int Index);
  esp_err_t           Delete(int Index);

  gpio_num_t          *m_pRowList;  
  gpio_num_t          *m_pColumnList;
  int                 m_RowCount;         
  int                 m_ColumnCount;    
  ESPButton           *m_pMatrix[];

private:
  esp_err_t           InitialiseIO(int32_t gpio_num, gpio_mode_t mode);

};

