/*
 *              LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include "esp_log.h"
#include "esp_err.h"
#include "esp_check.h"
#include "driver/gpio.h"
#include "ButtonIO.h"
#include "esp_sleep.h"
#include "ButtonIO.h"

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[ButnIO]";

static void PowerSaveISR(void *arg);

/////////////////////////////////////////////////////////////////////////////////////

GPIOButton::GPIOButton(void)
{
}

/////////////////////////////////////////////////////////////////////////////////////

GPIOButton::~GPIOButton()
{
 	gpio_reset_pin(m_GPIONumber);
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t GPIOButton::Create(const ButtonConfig_t *pConfig, const GPIOButtonConfig_t *pIOConfig)
{
esp_err_t ret = ESP_OK;
gpio_config_t GPIOConf = {};

	ESP_GOTO_ON_FALSE(pConfig && pIOConfig, ESP_ERR_INVALID_ARG, err, _TAG, "Invalid argument");
	ESP_GOTO_ON_FALSE(GPIO_IS_VALID_GPIO(pIOConfig->GPIONumber), ESP_ERR_INVALID_ARG, err, _TAG, "GPIO number error");
	m_GPIONumber = pIOConfig->GPIONumber;
	m_ActiveLevel = pIOConfig->ActiveLevel;
	m_PowerSave = pIOConfig->PowerSave;
	GPIOConf.intr_type = GPIO_INTR_DISABLE;
	GPIOConf.mode = GPIO_MODE_INPUT;
	GPIOConf.pin_bit_mask = (1ULL << pIOConfig->GPIONumber);
	if(!pIOConfig->DisableBias) {
		if(pIOConfig->ActiveLevel) {
			GPIOConf.pull_down_en = GPIO_PULLDOWN_ENABLE;
			GPIOConf.pull_up_en = GPIO_PULLUP_DISABLE;
		}
		else {
			GPIOConf.pull_down_en = GPIO_PULLDOWN_DISABLE;
			GPIOConf.pull_up_en = GPIO_PULLUP_ENABLE;
		}
	}
	gpio_config(&GPIOConf);
	if(pIOConfig->PowerSave) {
#if CONFIG_PM_POWER_DOWN_PERIPHERAL_IN_LIGHT_SLEEP
		if(!esp_sleep_is_valid_wakeup_gpio(pIOConfig->GPIONumber)) {
			ESP_LOGE(_TAG, "GPIO %ld is not a valid wakeup source under CONFIG_GPIO_BUTTON_SUPPORT_POWER_SAVE", pIOConfig->GPIONumber);
			return ESP_FAIL;
		}
		gpio_hold_en(pIOConfig->GPIONumber);
#endif
		/* Enable wake up from GPIO */
		ret = gpio_wakeup_enable(pIOConfig->GPIONumber, pIOConfig->ActiveLevel == 0 ? GPIO_INTR_LOW_LEVEL : GPIO_INTR_HIGH_LEVEL);
		ESP_GOTO_ON_FALSE(ret == ESP_OK, ESP_ERR_INVALID_STATE, err, _TAG, "Enable gpio wakeup failed");
#if CONFIG_PM_POWER_DOWN_PERIPHERAL_IN_LIGHT_SLEEP
#if SOC_PM_SUPPORT_EXT1_WAKEUP
		ret = esp_sleep_enable_ext1_wakeup_io((1ULL << pIOConfig->GPIONumber), pIOConfig->ActiveLevel == 0 ? ESP_EXT1_WAKEUP_ANY_LOW : ESP_EXT1_WAKEUP_ANY_HIGH);
#else
		ret = ESP_FAIL;		// Not support etc: esp32c2, esp32c3. Target must support ext1 wakeup 
		ESP_GOTO_ON_FALSE(ret == ESP_OK, ESP_FAIL, err, _TAG, "Target must support ext1 wakeup");
#endif
#else
		ret = esp_sleep_enable_gpio_wakeup();
#endif
		ESP_GOTO_ON_FALSE(ret == ESP_OK, ESP_FAIL, err, _TAG, "Configure gpio as wakeup source failed");
		ret = SetInterrupt(pIOConfig->ActiveLevel == 0 ? GPIO_INTR_LOW_LEVEL : GPIO_INTR_HIGH_LEVEL, PowerSaveISR);
		ESP_GOTO_ON_FALSE(ret == ESP_OK, ESP_FAIL, err, _TAG, "Set gpio interrupt failed");
	}
	ESPButton::Create(pConfig);
	ESP_GOTO_ON_FALSE(ret == ESP_OK, ESP_FAIL, err, _TAG, "Create button failed");
	return ESP_OK;
  
err:
	return ret;
}

/////////////////////////////////////////////////////////////////////////////////////

uint8_t GPIOButton::GetKeyLevel(void)
{
	int Level = gpio_get_level(m_GPIONumber);
	return Level == m_ActiveLevel ? 1 : 0;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t GPIOButton::EnableWakeup(uint8_t ActiveLevel, bool Enable)
{
esp_err_t ret;

	if(Enable) {
		gpio_intr_enable(m_GPIONumber);
		ret = gpio_wakeup_enable(m_GPIONumber, ActiveLevel == 0 ? GPIO_INTR_LOW_LEVEL : GPIO_INTR_HIGH_LEVEL);
	}
	else {
		gpio_intr_disable(m_GPIONumber);
		ret = gpio_wakeup_disable(m_GPIONumber);
	}
	return ret;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t GPIOButton::SetInterrupt(gpio_int_type_t InterruptType, gpio_isr_t Handler)
{
	static bool isr_service_installed = false;
	gpio_set_intr_type(m_GPIONumber, InterruptType);
	if(!isr_service_installed) {
		gpio_install_isr_service(ESP_INTR_FLAG_IRAM);
		isr_service_installed = true;
	}
	gpio_isr_handler_add(m_GPIONumber, Handler, (void *)m_GPIONumber);
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t GPIOButton::EnterPowerSave(void)
{
	return EnableWakeup(m_ActiveLevel, true);
}

/////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////

static void PowerSaveISR(void *arg)
{
//	iot_button_resume();	// resume the button 
//	button_gpio_enable_gpio_wakeup((*(gpio_num_t *)arg), 0, false);	// disable gpio wakeup not need active level
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t NewGPIOButton(const ButtonConfig_t *pConfig, const GPIOButtonConfig_t *pIOConfig, GPIOButton *pButton)
{
esp_err_t ret = ESP_OK;

	ESP_GOTO_ON_FALSE(pConfig && pIOConfig, ESP_ERR_INVALID_ARG, err, _TAG, "Invalid argument");
	ESP_GOTO_ON_FALSE(GPIO_IS_VALID_GPIO(pIOConfig->GPIONumber), ESP_ERR_INVALID_ARG, err, _TAG, "GPIO number error");
  pButton = new GPIOButton;
	ESP_GOTO_ON_FALSE(pButton, ESP_ERR_NO_MEM, err, _TAG, "No memory for GPIO button");
  pButton->Create(pConfig, pIOConfig);
	return ESP_OK;
  
err:
	if(pButton)	delete pButton;
	return ret;
}

/////////////////////////////////////////////////////////////////////////////////////

void DeleteGPIOButton(GPIOButton *pButton)
{
	delete pButton;
}

