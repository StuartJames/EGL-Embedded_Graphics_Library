/*
 *                LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#include <stdlib.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <driver/gpio.h>
#include <esp_system.h>
#include <esp_err.h>
#include <esp_check.h>
#include <esp_log.h>
#include "ESPEGTouchCST328.h"

/////////////////////////////////////////////////////////////////////////////////////

static const char *_TAG = "[TPBASE]";

/////////////////////////////////////////////////////////////////////////////////////

ESPGLTouchController::ESPGLTouchController(void)
{
}

/////////////////////////////////////////////////////////////////////////////////////

ESPGLTouchController::~ESPGLTouchController(void)
{
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchController::EnterSleep(void)
{
	ESP_LOGE(_TAG, "Sleep mode not supported!");
	return ESP_ERR_NOT_SUPPORTED;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchController::ExitSleep(void)
{
	ESP_LOGE(_TAG, "Sleep mode not supported!");
	return ESP_ERR_NOT_SUPPORTED;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchController::ReadData(void)
{
	ESP_LOGE(_TAG, "Read not supported!");
	return ESP_ERR_NOT_SUPPORTED;
}

/////////////////////////////////////////////////////////////////////////////////////

bool ESPGLTouchController::GetCoordinates(uint16_t *pX, uint16_t *pY, uint16_t *pStrength, uint8_t *pCount, uint8_t MaxCount)
{
	ESP_LOGE(_TAG, "Get coordinates not supported!");
	return false;
}

/////////////////////////////////////////////////////////////////////////////////////

#if(CONFIG_ESP_LCD_TOUCH_MAX_BUTTONS > 0)
esp_err_t ESPGLTouchController::GetButtonState(uint8_t n, uint8_t *state)
{
	ESP_LOGE(_TAG, "Get button state not supported!");
	return ESP_ERR_NOT_SUPPORTED;
}
#endif

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchController::SetSwapXY(bool swap)
{
	ESP_LOGE(_TAG, "Set swap XY not supported!");
	return ESP_ERR_NOT_SUPPORTED;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchController::GetSwapXY(bool *pSwap)
{
	ESP_LOGE(_TAG, "Get swap XY not supported!");
	return ESP_ERR_NOT_SUPPORTED;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchController::SetMirrorX(bool Mirror)
{
	ESP_LOGE(_TAG, "Set mirror X not supported!");
	return ESP_ERR_NOT_SUPPORTED;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchController::GetMirrorX(bool *pMirror)
{
	ESP_LOGE(_TAG, "Get mirror X not supported!");
	return ESP_ERR_NOT_SUPPORTED;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchController::SetMirrorY(bool Mirror)
{
	ESP_LOGE(_TAG, "Set mirror Y not supported!");
	return ESP_ERR_NOT_SUPPORTED;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchController::GetMirrorY(bool *pMirror)
{
	ESP_LOGE(_TAG, "Get mirror Y not supported!");
	return ESP_ERR_NOT_SUPPORTED;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchController::Delete(void)
{
	ESP_LOGE(_TAG, "Delete not supported!");
	return ESP_ERR_NOT_SUPPORTED;
}

/////////////////////////////////////////////////////////////////////////////////////

esp_err_t ESPGLTouchController::RegisterInterruptCB(ESPGL_LCDTouchInterruptCB_t InterruptCB)
{
esp_err_t ret = ESP_OK;

	if(m_Config.InterruptPin == GPIO_NUM_NC) {	// Interrupt pin is not selected 
		return ESP_ERR_INVALID_ARG;
	}
	if(InterruptCB != NULL) {
		ret = gpio_install_isr_service(0);
		if(ret != ESP_OK && ret != ESP_ERR_INVALID_STATE) {	// ISR service could already be installed, then it returns invalid state 
			ESP_LOGE(_TAG, "GPIO ISR install failed");
			return ret;
		}		// Add GPIO ISR handler 
		ret = gpio_intr_enable(m_Config.InterruptPin);
		ESP_RETURN_ON_ERROR(ret, _TAG, "GPIO ISR install failed");
		ret = gpio_isr_handler_add(m_Config.InterruptPin, (gpio_isr_t)m_Config.InterruptCB, this);
		ESP_RETURN_ON_ERROR(ret, _TAG, "GPIO ISR install failed");
	}
	else {		// Remove GPIO ISR handler 
		ret = gpio_isr_handler_remove(m_Config.InterruptPin);
		ESP_RETURN_ON_ERROR(ret, _TAG, "GPIO ISR remove handler failed");
		ret = gpio_intr_disable(m_Config.InterruptPin);
		ESP_RETURN_ON_ERROR(ret, _TAG, "GPIO ISR disable failed");
	}
	return ESP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////

void ESPGLTouchController::ESPGLPortTouchpadRead(EGInputDriver *pDriver, EG_InputData_t *pData)
{
uint16_t PointX = 0, PointY = 0;
uint8_t Count = 0;

	assert(pDriver);
  ESPGLTouchController *pController = (ESPGLTouchController*)pDriver->m_pController;
  pController->ReadData();	// Read data from touch controller into memory 
	bool Pressed = pController->GetCoordinates(&PointX, &PointY, NULL, &Count, 1);	// Read data from touch controller 
	if(Pressed && Count > 0){
		pData->Point.Set(PointX * pController->m_ScaleX, PointY* pController->m_ScaleY);
		pData->State = EG_INDEV_STATE_PRESSED;
	}
	else pData->State = EG_INDEV_STATE_RELEASED;
}

/////////////////////////////////////////////////////////////////////////////////////

EGInputDevice* ESPGLTouchController::AddTouchpad(ESPGLTouchController *pController, EGDisplay *pDisplay)
{
	assert(pDisplay != nullptr);
	assert(pController != nullptr);
  EGInputDriver *pDriver = new EGInputDriver;  // instigate a new software driver
  pDriver->m_pDisplay = pDisplay;
	EGInputDevice *pDevice = EGInputDevice::RegisterDriver(pDriver);  // attach the driver to a new device
  if(pDevice != nullptr){
  	pDevice->InitialiseDriver(pDevice->m_pDriver);	// Set defaults 
    pDevice->m_pDriver->m_pController = (void*)pController;
    pDevice->m_pDriver->m_Type = EG_INDEV_TYPE_POINTER;
    pDevice->m_pDriver->ReadCB = ESPGLTouchController::ESPGLPortTouchpadRead;
    pDevice->m_pDriver->m_pReadTimer->Start();
  }
  return pDevice;
}

/////////////////////////////////////////////////////////////////////////////////////

void TouchpadInitialise(ESPGLTouchController *pController, EGDisplay *pDisplay)
{
	assert(pController != nullptr);
 	pController->Initialise();
	ESPGLTouchController::AddTouchpad(pController, pDisplay);
}



