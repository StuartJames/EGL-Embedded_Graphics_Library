/*
 *                LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#pragma once

#include "esp_err.h"
#include "esp_lcd_panel_io.h"
#include "esp_lcd_panel_ops.h"
#include "EGL.h"

#if EG_VERSION_MAJOR == 8
#include "ESPEGPortCompatibility.h"
#endif

////////////////////////////////////////////////////////////////////////

#if CONFIG_IDF_TARGET_ESP32S3 && ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(5, 0, 0)
#include "esp_lcd_panel_rgb.h"
#endif

#if(CONFIG_IDF_TARGET_ESP32P4 && ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(5, 3, 0))
#include "esp_lcd_mipi_dsi.h"
#endif

#if(ESP_IDF_VERSION < ESP_IDF_VERSION_VAL(4, 4, 4)) || (ESP_IDF_VERSION == ESP_IDF_VERSION_VAL(5, 0, 0))
#define LVGL_PORT_HANDLE_FLUSH_READY 0
#else
#define LVGL_PORT_HANDLE_FLUSH_READY 1
#endif

/////////////////////////////////////////////////////////////////////////////////////

typedef enum {
    LVGL_PORT_DISP_TYPE_OTHER,
    LVGL_PORT_DISP_TYPE_DSI,
    LVGL_PORT_DISP_TYPE_RGB,
} ESPGLPortDisplayType_t;


typedef struct {
    bool swap_xy;  // LCD Screen swapped X and Y (in esp_lcd driver) 
    bool mirror_x; // LCD Screen mirrored X (in esp_lcd driver) 
    bool mirror_y; // LCD Screen mirrored Y (in esp_lcd driver) 
} ESPGLPortRotationCfg_t;

typedef struct {
    struct {
        unsigned int bb_mode: 1;        // 1: Use bounce buffer mode 
        unsigned int avoid_tearing: 1;  // 1: Use internal RGB buffers as a LVGL draw buffers to avoid tearing effect, enabling this option requires over two LCD buffers and may reduce the frame rate 
    } flags;
} ESPGLPortRGBCfg_t;

typedef struct {
    struct {
        unsigned int avoid_tearing: 1;  // 1: Use internal MIPI-DSI buffers as a LVGL draw buffers to avoid tearing effect, enabling this option requires over two LCD buffers and may reduce the frame rate 
    } flags;
} ESPGLPortDSICfg_t;


typedef struct {
  uint32_t    BufferSize;        // Size of the buffer for the screen in pixels 
  bool        DoubleBuffer;      // True, if should be allocated two buffers 
  uint32_t    TransferSize;         // Allocated buffer will be in SRAM to move framebuf (optional) 

  uint32_t    HoriResolution;           // LCD display horizontal resolution 
  uint32_t    VertvResolution;           // LCD display vertical resolution 

  bool        IsMonochrome;     // True, if display is monochrome and using 1bit for 1px 

  ESPGLPortRotationCfg_t Rotation;      // Default values of the screen rotation (Only HW state. Not supported for default SW rotation!) 
#if EG_VERSION_MAJOR >= 9
  lv_color_format_t        color_format;  // The color format of the display 
#endif
  struct {
    unsigned int BufferDMA: 1;    // Allocated LVGL buffer will be DMA capable 
    unsigned int BuffersPSRAM: 1; // Allocated LVGL buffer will be in PSRAM 
    unsigned int SWRotate: 1;   // Use software rotation (slower) or PPA if available 
#if EG_VERSION_MAJOR >= 9
    unsigned int SwapBytes: 1;  // Swap bytes in RGB565 (16-bit) color format before send to LCD driver 
#endif
    unsigned int FullRefresh: 1;// 1: Always make the whole screen redrawn 
    unsigned int DirectMode: 1; // 1: Use screen-sized buffers and draw to absolute coordinates 
  } Flags;
} ESPGLPortDisplayCfg_t;

/////////////////////////////////////////////////////////////////////////////////////

class ESPGLLCDDriver : public EGDisplayDriver
{
public:
                      ESPGLLCDDriver(void) : EGDisplayDriver() {};
  virtual             ~ESPGLLCDDriver();
  static void         Flush(EGDisplayDriver *pDisplayDriver, const EGRect *pRect, EG_Color_t *pColorMap);
  static void         Update(EGDisplayDriver *pDisplayDriver);
  static void         PixMonochrome(EGDisplayDriver *pDisplayDriver, uint8_t *pBuffer, EG_Coord_t buf_w, EG_Coord_t x, EG_Coord_t y, EG_Color_t Color, EG_OPA_t OPA);

#if LVGL_PORT_HANDLE_FLUSH_READY
  static bool         FlushIOReady(esp_lcd_panel_io_handle_t hIO, esp_lcd_panel_io_event_data_t *pEventData, void *pUserContext);
#if(CONFIG_IDF_TARGET_ESP32S3 && ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(5, 0, 0))
  static bool         FlushRGBVsyncReady(esp_lcd_panel_handle_t hIO, const esp_lcd_rgb_panel_event_data_t *pEventData, void *pUserContext);
#endif
#if(CONFIG_IDF_TARGET_ESP32P4 && ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(5, 3, 0))
  static bool         FlushDPIPanelReady(esp_lcd_panel_handle_t hIO, esp_lcd_dpi_panel_event_data_t *pEventData, void *pUserContext);
  static bool         FlushDPIVsyncReady(esp_lcd_panel_handle_t hIO, esp_lcd_dpi_panel_event_data_t *pEventData, void *pUserContext);
#endif
#endif
};

/////////////////////////////////////////////////////////////////////////////////////

class ESPGLDisplay
{
public:
                            ESPGLDisplay(void);
  virtual                   ~ESPGLDisplay();

  EGDisplay*                AddDisplay(esp_lcd_panel_handle_t hPanel, esp_lcd_panel_io_handle_t hIO, ESPGLPortDisplayCfg_t *pConfig);
  EGDisplay*                AddDisplayDSI(esp_lcd_panel_handle_t hPanel, esp_lcd_panel_io_handle_t hIO, ESPGLPortDisplayCfg_t *pConfig, const ESPGLPortDSICfg_t *dsi_cfg);
  EGDisplay*                AddDisplayRGB(esp_lcd_panel_handle_t hPanel, esp_lcd_panel_io_handle_t hIO, ESPGLPortDisplayCfg_t *pConfig, const ESPGLPortRGBCfg_t *rgb_cfg);
  esp_err_t                 RemoveDisplay(EGDisplay *pDisplay);
  ESPGLLCDDriver*           GetDriver(void){ return m_pDriver; };

  esp_lcd_panel_io_handle_t m_hIO;                // LCD panel IO handle 
  esp_lcd_panel_handle_t    m_hPanel;             // LCD panel handle 
  esp_lcd_panel_handle_t    m_hControl;           // LCD panel control handle 
	SemaphoreHandle_t         m_hTransferSemaphore; // Idle transfer mutex 
	ESPGLPortDisplayType_t    m_DisplayType;        // Display type 
  ESPGLPortRotationCfg_t    m_Rotation;           // Default values of the screen rotation (Only HW state. Not supported for default SW rotation!) 
  uint32_t                  m_TransferSize;       // Allocated buffer will be in SRAM to move framebuf (optional) 
	EG_Color_t                *m_pTransferBuffer;   // Buffer send to driver 

private:
  void                      Configure(esp_lcd_panel_handle_t hPanel, esp_lcd_panel_io_handle_t hIO, ESPGLPortDisplayCfg_t *pConfig);
  EGDisplay*                AddDisplayPrivate(const bool AvoidTearing);

  ESPGLLCDDriver           *m_pDriver;
  uint32_t                  m_BufferSize;         // Size of the buffer for the screen in pixels 
  bool                      m_DoubleBuffer;       // True, if should be allocated two buffers 
  uint32_t                  m_HoriResolution;     // LCD display horizontal resolution 
  uint32_t                  m_VertvResolution;    // LCD display vertical resolution 
  bool                      m_IsMonochrome;       // True, if display is monochrome and using 1bit for 1px 
#if EG_VERSION_MAJOR >= 9
  lv_color_format_t         m_ColorFormat;  // The color format of the display 
#endif

  unsigned int              m_BufferDMA: 1;       // Allocated LVGL buffer will be DMA capable 
  unsigned int              m_BuffersPSRAM: 1;    // Allocated LVGL buffer will be in PSRAM 
  unsigned int              m_SWRotate: 1;        // Use software rotation (slower) or PPA if available 
#if EG_VERSION_MAJOR >= 9
  unsigned int              m_SwapBytes: 1;       // Swap bytes in RGB565 (16-bit) color format before send to LCD driver 
#endif
  unsigned int              m_FullRefresh: 1;     // 1: Always make the whole screen redrawn 
  unsigned int              m_DirectMode: 1;      // 1: Use screen-sized buffers and draw to absolute coordinates 

};
