/*
 *                LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

 #pragma once

#include <stdbool.h>
#include <sdkconfig.h>
#include <esp_err.h>
#include <driver/gpio.h>
#include <esp_lcd_panel_io.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>
#include "EGL.h"

#if EG_VERSION_MAJOR == 8
//#include "ESPEGPortCompatibility.h"
#endif

#define CONFIG_ESP_LCD_TOUCH_MAX_POINTS 5

/////////////////////////////////////////////////////////////////////////////////////

typedef void (*ESPGL_LCDTouchInterruptCB_t)(void *pDriver);

typedef struct {
    uint16_t MaxX; // X coordinates max (for mirroring) 
    uint16_t MaxY; // Y coordinates max (for mirroring) 

    gpio_num_t ResetPin;    // GPIO number of reset pin 
    gpio_num_t InterruptPin;    // GPIO number of interrupt pin 

    struct {
        unsigned int Reset: 1;    // Level of reset pin in reset 
        unsigned int Interrupt: 1;// Active Level of interrupt pin 
    } Levels;

    struct {
        unsigned int SwapXY: 1;  // Swap X and Y after read coordinates 
        unsigned int MirrorX: 1; // Mirror X after read coordinates 
        unsigned int MirrorY: 1; // Mirror Y after read coordinates 
    } Flags;
//    void (*process_coordinates)(uint16_t *x, uint16_t *y, uint16_t *strength, uint8_t *point_num, uint8_t max_point_num);    // User callback called after the touch interrupt occured 
    ESPGL_LCDTouchInterruptCB_t InterruptCB;
} ESPGL_LCDTouchConfig_t;


typedef struct {
    uint8_t Points; // Count of touch points saved 
    struct {
        uint16_t X; // X coordinate 
        uint16_t Y; // Y coordinate 
        uint16_t Strength; // Strength 
    } Coords[CONFIG_ESP_LCD_TOUCH_MAX_POINTS];
#if (CONFIG_ESP_LCD_TOUCH_MAX_BUTTONS > 0)
    uint8_t Buttons; // Count of buttons states saved 
    struct {
        uint8_t status; // Status of button 
    } Button[CONFIG_ESP_LCD_TOUCH_MAX_BUTTONS];
#endif
} ESPGLTouchData_t;

typedef struct {
  EGDisplay       *pDisplay;        // LVGL display handle (returned from lvgl_port_add_disp) 
  void            *pController;     // LCD touchpad IO controller 
  struct{
    float X;
    float Y;            // Touchpad scale 
  } Scale;
} ESPGLPortTouchCfg_t;

/////////////////////////////////////////////////////////////////////////////////////

class ESPGLTouchController
{
public:
                              ESPGLTouchController(void);
  virtual                     ~ESPGLTouchController(void);
  virtual void                Initialise(void) = 0;
  virtual esp_err_t           Delete(void);  // Delete Touch
  virtual esp_err_t           EnterSleep(void);  // set touch controller into sleep mode
  virtual esp_err_t           ExitSleep(void); // set touch controller into normal mode
  virtual esp_err_t           ReadData(void);  // Read data from touch controller (mandatory)
  virtual bool                GetCoordinates(uint16_t *pX, uint16_t *pY, uint16_t *pStrength, uint8_t *pCount, uint8_t MaxCount); // Get coordinates from touch controller (mandatory)
#if (CONFIG_ESP_LCD_TOUCH_MAX_BUTTONS > 0)
  virtual esp_err_t           GetButtonState)(uint8_t n, uint8_t *state); // Get button state (optional)
#endif
  virtual esp_err_t           SetSwapXY(bool swap); // Swap X and Y after read coordinates (optional)
  virtual esp_err_t           GetSwapXY(bool *swap);  // Are X and Y coordinates swapped (optional)
  virtual esp_err_t           SetMirrorX(bool mirror);  // Mirror X after read coordinates
  virtual esp_err_t           GetMirrorX(bool *mirror); // Is mirrored X (optional)
  virtual esp_err_t           SetMirrorY(bool mirror); // Mirror Y after read coordinates. If set, then not used SW mirroring.
  virtual esp_err_t           GetMirrorY(bool *mirror); //Is mirrored Y (optional)
  esp_err_t                   RegisterInterruptCB(ESPGL_LCDTouchInterruptCB_t InterruptCB);

  static void                 ESPGLPortTouchpadRead(EGInputDriver *pDriver, EG_InputData_t *pData);
  static EGInputDevice*       AddTouchpad(ESPGLTouchController *pController, EGDisplay *pDisplay);

  const EGInputDriver        *m_pDriver;      // Input device driver
//  const EGDisplay            *m_pDisplay;     // display handle (returned from lvgl_port_add_disp) 

	float                       m_ScaleX;       // Touchpad scale 
	float                       m_ScaleY;
  ESPGL_LCDTouchConfig_t      m_Config;       // Configuration structure
  esp_lcd_panel_io_handle_t   m_hIO;          // Communication interface
  ESPGLTouchData_t            m_Data;         // Data structure
  portMUX_TYPE                m_Lock;         // Lock for read/write 

};

/////////////////////////////////////////////////////////////////////////////////////

void TouchpadInitialise(ESPGLTouchController *pTouchController, EGDisplay *pDisplay);


