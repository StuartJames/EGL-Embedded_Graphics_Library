/*
 *                LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#pragma once

#include "esp_err.h"
#include "EGL.h"
#include "esp_timer.h"
#include "ESPEGLCDDriver.h"
#include "ESPEGTouchController.h"
#include "ESPEGPortUSBHid.h"

#include "ESPEGPortCompatibility.h"

/////////////////////////////////////////////////////////////////////////////////////

typedef enum {
    LVGL_PORT_EVENT_DISPLAY = 0x01,
    LVGL_PORT_EVENT_TOUCH   = 0x02,
    LVGL_PORT_EVENT_USER    = 0x80,
} lvgl_port_event_type_t;

typedef struct {
    lvgl_port_event_type_t type;
    void *param;
} lvgl_port_event_t;

/////////////////////////////////////////////////////////////////////////////////////

const int c_TaskPriority = 4;
const int c_TaskStack = 7168;
const int c_TaskAffinity = -1;
const int c_TaskMaxSleep = 500;
const int c_TimerPeriod = 5;


/////////////////////////////////////////////////////////////////////////////////////

class ESPGLPort
{
public:
                      ESPGLPort(void);
  virtual             ~ESPGLPort();
  esp_err_t           Initialise(int Priority, int Stack, int Affinity, int SleepPeriod, int TimerPeriod);
  esp_err_t           Deinitialise(void);
  void                TaskDeinitialise(void);
  bool                Lock(uint32_t timeout_ms);
  void                Unlock(void);
//  void                FlushReady(lv_display_t *disp);
  esp_err_t           Stop(void);
  esp_err_t           Resume(void);
  esp_err_t           Wake(lvgl_port_event_type_t event, void *param);
  SemaphoreHandle_t   GetTaskMux(void){ return m_hTaskMux; };
  int                 GetTaskPeriod(void){ return m_TaskMaxSleep; };
  int                 GetTimerPeriod(void){ return m_TimerPeriod; };

 	bool                m_IsRunning;

private:
  esp_err_t           TickInitialise(void);	

  int                 m_TaskMaxSleep; // Task sleep period in ms
  int                 m_TimerPeriod;    // timer tick period in ms 
	TaskHandle_t        m_hTask;
	SemaphoreHandle_t   m_hMux;
	SemaphoreHandle_t   m_hTaskMux;
	esp_timer_handle_t m_hTickTimer;

};
