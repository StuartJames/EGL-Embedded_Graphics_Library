/**
 * @file EG_Themes.h
 *
 */

#pragma once

#include "EG_DefaultTheme.h"
#include "EG_MonoTheme.h"
#include "EG_BasicTheme.h"

