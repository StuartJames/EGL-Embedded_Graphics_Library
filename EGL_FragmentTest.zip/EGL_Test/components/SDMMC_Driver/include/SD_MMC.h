/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original WeatherClock
 *
 */

#pragma once

/////////////////////////////////////////////////////////////////////////////////////

#include <string.h>
#include <sys/unistd.h>
#include <sys/stat.h>
#include <esp_vfs_fat.h>
#include <dirent.h>
#include <sdmmc_cmd.h>
#include <driver/sdmmc_host.h>
#include <esp_log.h>
#include <errno.h>

#include "esp_flash.h"

/////////////////////////////////////////////////////////////////////////////////////

#define MAX_LINE_CHAR_SIZE 64
#define MAX_FILE_NAME_SIZE 100  // Define maximum file name size
#define MAX_PATH_SIZE 512       // Define a larger size for the full path

/////////////////////////////////////////////////////////////////////////////////////

class SDMMCDevice
{
public:
              SDMMCDevice(void);
  void        Initialise(const char *pMountPoint);
  void        GetFlashSize(void);
  FILE*       OpenFile(const char *pFilePath, const char *pMode);
  void        CloseFile(FILE *pFile);
  esp_err_t   WriteRaw(FILE *pFile, char *pSrce, int Count);
  esp_err_t   ReadRaw(FILE *pFile, char *pDest, int Count);
  uint16_t    RetreiveFolder(const char *pDirectory, const char *pFileExtension, char File_Name[][MAX_FILE_NAME_SIZE], uint16_t MaxFiles);
  uint32_t    SDCardSizeIs(void){ return m_SDCardSize; };
  uint32_t    FlashSizeIs(void){ return m_FlashSize; };
  void        Goto(FILE *pFile, size_t Pos){ fseek(pFile, Pos, SEEK_SET);};
  uint32_t    GetPos(FILE *pFile){ return ftell(pFile);};
  const char* GetMountPoint(void){ return m_pMountPoint; };

private:
  uint32_t    m_SDCardSize;
  uint32_t    m_FlashSize;
  const char  *m_pMountPoint;
};