/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original WeatherClock
 *
 */

 #pragma once

#include <stdint.h>
#include <string.h>  // For memcpy
#include <esp_log.h>
#include <driver/gpio.h>
#include <driver/i2c.h>

/////////////////////////////////////////////////////////////////////////////////////

class I2CDriver
{
public:
                  I2CDriver();
  void            Initialise(gpio_num_t SCL, gpio_num_t SDA, i2c_port_t Port);
  esp_err_t       Write(uint8_t Address, uint8_t Register, const uint8_t *pData, uint32_t Length);
  esp_err_t       Read(uint8_t Address, uint8_t Register, uint8_t *pData, uint32_t Length);

private:
  i2c_port_t m_Port;
  gpio_num_t m_SCLPin;      // GPIO number used for I2C master clock 
  gpio_num_t m_SDAPin;      // GPIO number used for I2C master data  
};