/*
 *                LEGL 2025-2026 HydraSystems.
 *
 *  This program is free software; you can redistribute it and/or   
 *  modify it under the terms of the GNU General Public License as  
 *  published by the Free Software Foundation; either version 2 of  
 *  the License, or (at your option) any later version.             
 *                                                                  
 *  This program is distributed in the hope that it will be useful, 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of  
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the   
 *  GNU General Public License for more details.                    
 * 
 *  Based on a design by LVGL Kft
 * 
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/08/18   1.a.1    Original by LVGL Kft
 *
 */

#pragma once

#include "driver/gpio.h"
#include "driver/sdmmc_host.h"
#include "esp_lcd_types.h"
#include "sdkconfig.h"
#include "EGL.h"
#include "ESPEGPort.h"
#include "ESPEGTouchCST328.h"

/**************************************************************************************************
 *  BSP Capabilities
 **************************************************************************************************/

#define ESP_LCD_COLOR_FORMAT_RGB565    	(1)
#define ESP_LCD_COLOR_FORMAT_RGB888    	(2)

#define BSP_LCD_COLOR_FORMAT        		(ESP_LCD_COLOR_FORMAT_RGB565)   // LCD display color format 
#define BSP_LCD_BIGENDIAN           		(1) 														// LCD display color bytes endianess 
#define BSP_LCD_BITS_PER_PIXEL      		(16)                            // LCD display color bits 
#ifdef CONFIG_BSP_LCD_ILI9341                                       // LCD display color space 
#define BSP_LCD_COLOR_SPACE         		(ESP_LCD_COLOR_SPACE_BGR)
#else
#define BSP_LCD_COLOR_SPACE         		(ESP_LCD_COLOR_SPACE_RGB)
#endif

#define BSP_LCD_H_RES               		(240)
#define BSP_LCD_V_RES               		(320)

#define BSP_CAPS_DISPLAY        1
#define BSP_CAPS_TOUCH          0
#define BSP_CAPS_BUTTONS        1
#define BSP_CAPS_AUDIO          0
#define BSP_CAPS_AUDIO_SPEAKER  0
#define BSP_CAPS_AUDIO_MIC      0
#define BSP_CAPS_LED            1
#define BSP_CAPS_SDCARD         1
#define BSP_CAPS_IMU            0


typedef enum bsp_led_t {
    BSP_LED_RED = GPIO_NUM_0,
    BSP_LED_GREEN = GPIO_NUM_2,
    BSP_LED_BLUE = GPIO_NUM_4
} bsp_led_t;

const spi_host_device_t BSP_LCD_SPI_Num_c   = SPI2_HOST;
#define BSP_LCD_PIXEL_CLOCK_HZ      				40 * 1000 * 1000
#define BSP_LCD_DRAW_BUFF_SIZE      				BSP_LCD_H_RES * 30
#define BSP_LCD_DRAW_BUFF_DOUBLE    				1

#define BSP_SPIFFS_MOUNT_POINT      CONFIG_BSP_SPIFFS_MOUNT_POINT
#define BSP_SD_MOUNT_POINT      		CONFIG_BSP_SD_MOUNT_POINT

/////////////////////////////////////////////////////////////////////////////////////

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
  BSP_BUTTON_BOOT,
  BSP_BUTTON_NUM
} bsp_button_t;

typedef struct {
	gpio_num_t	SPI_MOSI;
	gpio_num_t	SPI_MISO;
	gpio_num_t	SPI_CLK;
	gpio_num_t	SPI_CS;
	gpio_num_t	LCD_DC;
	gpio_num_t	LCD_RST;
	gpio_num_t	LCD_BCK;
} DisplayPins_t;

/////////////////////////////////////////////////////////////////////////////////////

extern sdmmc_card_t *pSDCard;

/////////////////////////////////////////////////////////////////////////////////////


esp_err_t 		NewDisplay(const DisplayPins_t *pPins, esp_lcd_panel_handle_t *hPanel, esp_lcd_panel_io_handle_t *hIO);
esp_err_t 		LED_Initialise(const DisplayPins_t *pPins);
esp_err_t 		Set_LED(const bsp_led_t LEDRef, const bool State);
esp_err_t 		MountSPIFFS(void);
esp_err_t 		UnmountSPIFFS(void);
esp_err_t 		MountSDCard(void);
esp_err_t 		UnmountSDCard(void);
esp_err_t 		BacklightIntialise(gpio_num_t BackLightPin);
esp_err_t 		SetBacklightLevel(int Intensity);
esp_err_t 		BacklightOn(void);
esp_err_t 		BacklightOff(void);
EGDisplay 	  *DisplayStart(DisplayPins_t *pPins);
EGInputDevice	*GetInputDevice(void);
bool 					DisplayLock(uint32_t Timeout);
void 					DisplayUnlock(void);
void 					DisplayRotate(EGDisplay *pDisplay, EG_DisplayRotation_e Rotation);

#ifdef __cplusplus
}
#endif
