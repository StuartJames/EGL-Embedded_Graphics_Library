/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original LEGLDemo
 *
 */

#pragma once

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#include <time.h>
#include <sys/time.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/event_groups.h>
#include <freertos/semphr.h>
#include <freertos/queue.h>
#include <freertos/timers.h>
#include <esp_wifi.h>
#include <esp_wifi_default.h>
#include "esp_http_client.h"
#include <esp_event.h>
#include <nvs_flash.h>
#include <esp_timer.h>
#include <esp_log.h>

#include <esp_system.h>
#include <esp_vfs.h>
#include <time.h>

#include "S3TouchBSP.h"
#include "EGL.h"

#include "RTCDevice.h"
#include "SD_MMC.h"

#include "BatteryDriver.h"
#include "PowerKey.h"
#include "Display.h"
#include "NVSUtils.h"
#include "TestUI.h"

/////////////////////////////////////////////////////////////////////////////////////

//#define WIDGET_TEST
//#define MESSAGE_TEST
//#define GRIDNAV_TEST
#define FRAGMENT_TEST


#define PI					              3.14159265358979323846
#define DEG2RAD(x) ((double)(x) * (PI / 180))
#define RAD2DEG(x) ((double)(x) * (180 / PI))

#define SECONDS_TO_TICKS(xTimeInS) ((TickType_t)(xTimeInS) * configTICK_RATE_HZ)
#define TICKS_TO_SECONDS(xTicks) ((TickType_t)(xTicks) / configTICK_RATE_HZ)

#define SYSFLAG_DISPLAY_READY     0x0001
#define SYSFLAG_SYSTEM_UP         0x0010
#define SYSFLAG_WIFI_CONNECTED    0x0020
#define SYSFLAG_WIFI_FAIL         0x0040
#define SYSFLAG_WEATHER_AQUIRED   0x0080
#define SYSFLAG_WEATHER_FAIL      0x0100
#define SYSFLAG_GPS_UPDATE        0x0200
#define SYSFLAG_GET_WEATHER       0x0400
#define SYSFLAG_SLEEPTIMER_EXP    0x8000

#define SCAN_DURATION             5
#define MAX_DISCOVERED_DEVICES    100

#define GPS_TIMER_ID              0
#define WEATHER_TIMER_ID          1

#define WIFI_SSID_SIZE            32
#define WIFI_PW_SIZE              64
#define WIFI_MAXIMUM_RETRY        6
#define CITY_NAME_SIZE            50
#define API_KEY_SIZE              35
#define WIFI_MAXIMUM_RETRY        6
#define MINIMUM_POLL_PERIOD       30
#define MAX_HTTP_RECV_BUFFER      1023
#define MAX_HTTP_OUTPUT_BUFFER    2048

#define GUI_EVENT_QUEUE_LEN       5

#define SECS_PER_MIN              60
#define SECS_PER_DAY              86400

/////////////////////////////////////////////////////////////////////////////////////

typedef enum {
  SYS_MSG_EV_NONE = 0,
  SYS_MSG_EV_WEATHER_UPDATE,  // Event for temperature and humidity update
  SYS_MSG_EV_TIME_UPDATE,     // Event for updating the time on clock
  SYS_MSG_EV_WIFI_CONNECTED,  // Event for device connected with WiFi and SNTP started
  SYS_MSG_EV_SNTP_SYNC,       // Event for time sync
  SYS_MSG_EV_GPS_UPDATE,      // Event for updating GPS data
  SYS_MSG_EV_MAX,
} EventMsgID_e;

typedef struct QueueMsg_t {
  EventMsgID_e  EventID;
  void          *pData;
} QueueMsg_t;


/////////////////////////////////////////////////////////////////////////////////////

const gpio_num_t        BSP_BootButtonPin_c = GPIO_NUM_0;
const gpio_num_t        LCD_SPI_MOSI_Pin_c 	= GPIO_NUM_45;
const gpio_num_t        LCD_SPI_MISO_Pin_c 	= GPIO_NUM_46;
const gpio_num_t        LCD_SPI_CLK_Pin_c 	= GPIO_NUM_40;
const gpio_num_t        LCD_SPI_CS_Pin_c 		= GPIO_NUM_42;
const gpio_num_t        LCD_DC_Pin_c 				= GPIO_NUM_41;
const gpio_num_t        LCD_RST_Pin_c 			= GPIO_NUM_39;
const gpio_num_t        LCD_BacklightPin_c 	= GPIO_NUM_5;
const gpio_num_t        SD_D0_Pin_c 				= GPIO_NUM_2;
const gpio_num_t        SD_D1_Pin_c 				= GPIO_NUM_4;
const gpio_num_t        SD_D2_Pin_c 				= GPIO_NUM_12;
const gpio_num_t        SD_D3_Pin_c 				= GPIO_NUM_13;
const gpio_num_t        SD_CMD_Pin_c 				= GPIO_NUM_15;
const gpio_num_t        SD_CLK_Pin_c 				= GPIO_NUM_14;
const gpio_num_t        SD_DET_Pin_c 				= GPIO_NUM_21;

const gpio_num_t 	      I2CSCLPin_c         = GPIO_NUM_10;     // GPIO number used for I2C master clock 
const gpio_num_t 	      I2CSDAPin_c         = GPIO_NUM_11;     // GPIO number used for I2C master data  
const i2c_port_t 	      I2CPort_c           = I2C_NUM_0;       // I2C master i2c port number
const gpio_num_t        PowerKeyPin_c       = GPIO_NUM_6;
const gpio_num_t        PowerControlPin_c   = GPIO_NUM_7;
const adc_channel_t     BatteryStateChannel_c = ADC_CHANNEL_7;
const adc_atten_t       BatteryStateAtten_c = ADC_ATTEN_DB_12;

/////////////////////////////////////////////////////////////////////////////////////

#ifdef _MAIN_

const char              *pVersionStr_c = "Version 1.a.023";
const char              *pServerURL_c = "api.openweathermap.org";    // remote server we will connect to
const char              *pMountPoint_c = "/sdcard";

EventGroupHandle_t      g_SystemFlags = NULL;
QueueHandle_t           g_EventQueue = NULL;

esp_timer_handle_t      g_hOneSecondTimer;
esp_timer_handle_t      g_hOneHourTimer;

I2CDriver               g_I2CObj;
RTCDevice               g_RTCObj;
Battery                 g_BatObj;
SDMMCDevice             g_SDMMCObj;
PowerKey                g_PwrKeyObj;

char                    g_APIKey[API_KEY_SIZE] = CONFIG_WEATHER_API_KEY; // g_APIKey is a passtoken used to identify the request from data to "pool.ntp.org
float                   g_WeatherLocation[2] = {52.49048, 1.23532};    // default to Norwich
char					          g_City[CITY_NAME_SIZE];											// computed nearest city to location
char                    g_RelpyBuffer[MAX_HTTP_OUTPUT_BUFFER + 1] = {0};
bool                    g_NVSAvailable = false;
uint8_t                 g_WiFiSSID[WIFI_SSID_SIZE + 1] = {0};
uint8_t                 g_WiFiPassword[WIFI_PW_SIZE + 1] = {0};

double                  g_Temperature = 0.0;
int                     g_HumidityPer = 0;
int                     g_Pressure = 0;
int                     g_Visibility = 0;
int                     g_WeatherID = 0;
char                    g_sDescription[30];
float                   g_WindSpeed = 0.0;
int                     g_WindAngle = 0;
int                     g_Cloud = 0;
float                   g_TemperatureFlt = 0.0;

#else

extern const char           *pServerURL_c;

extern EventGroupHandle_t   g_SystemFlags;
extern QueueHandle_t        g_EventQueue;

extern esp_timer_handle_t   g_hOneSecondTimer;
extern esp_timer_handle_t   g_hOneHourTimer;

extern I2CDriver            g_I2CObj;
extern RTCDevice            g_RTCObj;
extern Battery              g_BatObj;
extern SDMMCDevice          g_SDMMCObj;
extern PowerKey             g_PwrKeyObj;

extern char                 g_APIKey[]; // g_APIKey is a passtoken used to identify the request for data from "pool.ntp.org
extern float                g_WeatherLocation[];
extern char					        g_City[];
extern char                 g_RelpyBuffer[];
extern bool             		g_NVSAvailable;
extern uint8_t              g_WiFiSSID[WIFI_SSID_SIZE + 1];
extern uint8_t              g_WiFiPassword[WIFI_PW_SIZE + 1];

extern double               g_Temperature;
extern int                  g_HumidityPer;
extern char                 g_Pressure;
extern int                  g_Visibility;
extern int                  g_WeatherID;
extern char                 g_sDescription[];
extern float                g_WindSpeed;
extern int                  g_WindAngle;
extern int                  g_Cloud;
extern float                g_TemperatureFlt;
extern char                 g_pZoneStr[];

#endif

/////////////////////////////////////////////////////////////////////////////////////
