/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 *pEventdit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original LEGLDemo
 *
 */

#include "EGLTest.h"


/////////////////////////////////////////////////////////////////////////////

#ifdef MESSAGE_TEST

#define MSG_NEW_TEMPERATURE     1

static void SliderEventCB(EGEvent *pEvent);
static void LabelEventCB(EGEvent *pEvent);
static char ExtData[] = "%d °C";

/////////////////////////////////////////////////////////////////////////////

void EG_MessageTest(void)
{
	EGDisplay *pDisp = EGDisplay::GetDefault();
  pDisp->SetRotation(EG_DISP_ROT_NONE);
#if EG_USE_THEME_DEFAULT
	EGDefTheme::SetTheme(EG_MainPalette(EG_PALETTE_BLUE), EG_MainPalette(EG_PALETTE_RED), EG_THEME_DEFAULT_DARK, EG_FONT_DEFAULT, pDisp);
#endif
 
  EGObject *pScreen = EGDisplay::GetActiveScreen(pDisp);
   // Create a slider in the center of the display
  EGSlider *pSlider = new EGSlider(pScreen);
  pSlider->Center();
  EGEvent::AddEventCB(pSlider, SliderEventCB, EG_EVENT_VALUE_CHANGED, nullptr);

  // Create a label below the slider
  EGLabel *pLabel = new EGLabel(pScreen);
  EGEvent::AddEventCB(pLabel, LabelEventCB, EG_EVENT_MSG_RECEIVED, NULL);
  pLabel->SetText("0%");
  pLabel->Align(EG_ALIGN_CENTER, 0, 30);

  // Subscribe the label to a message. Also use the user_data to set a format string here.
  EGMessageExec::SubsribeObj(MSG_NEW_TEMPERATURE, pLabel, ExtData);
}

///////////////////////////////////////////////////////////////////////////////

static void SliderEventCB(EGEvent *pEvent)
{
  // Notify all subscribers (only the label now) that the slider value has been changed
  EGSlider *pSlider = (EGSlider*)pEvent->GetTarget();
  int32_t Value = pSlider->GetValue();
  EGMessageExec::Notify(MSG_NEW_TEMPERATURE, &Value);
}

///////////////////////////////////////////////////////////////////////////////

static void LabelEventCB(EGEvent *pEvent)
{
  EGLabel *pLabel = (EGLabel*)pEvent->GetTarget();
  EGMessage *pMessage = EGMessageExec::GetMessage(pEvent);
  if(pMessage){
    const char *pFormat = (char*)pMessage->GetExtData();
    const int32_t *pValue = (int32_t*)pMessage->GetPayload();
    pLabel->SetFormatText(pFormat, *pValue);
  }
}

#endif


