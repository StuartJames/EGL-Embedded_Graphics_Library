/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 *pEventdit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original LEGLDemo
 *
 */

#include "EGLTest.h"

#if EG_USE_GRID == 0
#error "LV_USE_GRID needs to be enabled"
#endif

#if EG_USE_FLEX == 0
#error "LV_USE_FLEX needs to be enabled"
#endif

// IMAGES AND IMAGE SETS
EG_IMG_DECLARE(ImageAvatar);
EG_IMG_DECLARE(ImageClothes);
EG_IMG_DECLARE(ImageLogo);

void EG_WidgetsDemo(void);
void EG_MessageTest(void);
void EG_GridNavTest(void);
void EG_FragmentTest(void);
