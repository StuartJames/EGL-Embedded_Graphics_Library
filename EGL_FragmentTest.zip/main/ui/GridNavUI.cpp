/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 *pEventdit     Date     Version       Edit Description
 * ====  ==========  ======= =====================================================
 * SJ    2025/04/18   1.a.1   Original LEGLDemo
 *
 */

#include "EGLTest.h"


/////////////////////////////////////////////////////////////////////////////

#ifdef GRIDNAV_TEST

/////////////////////////////////////////////////////////////////////////////

void EG_GridNavTest(void)
{
	EGDisplay *pDisp = EGDisplay::GetDefault();
  pDisp->SetRotation(EG_DISP_ROT_NONE);
#if EG_USE_THEME_DEFAULT
	EGDefTheme::SetTheme(EG_MainPalette(EG_PALETTE_BLUE), EG_MainPalette(EG_PALETTE_RED), EG_THEME_DEFAULT_DARK, EG_FONT_DEFAULT, pDisp);
#endif
  EGGroup *pGroup = EGGroup::Create();
  pGroup->SetAsDefault();
  EGObject *pScreen = EGDisplay::GetActiveScreen(pDisp);

  EGObject *pCont1 = new EGObject(pScreen);
  EGGridNav::Install(pCont1, EG_GRIDNAV_CTRL_NONE);

    // Use flex here, but works with grid or manually placed objects as well
  EGFlexLayout::SetObjFlow(pCont1, EG_FLEX_FLOW_ROW_WRAP);
  pCont1->SetStyleBackColor(EG_LightPalette(EG_PALETTE_BLUE, 5), EG_STATE_FOCUSED);
  pCont1->SetSize(EG_PCT(50), EG_PCT(100));

    // Only the container needs to be in a group
  EGGroup::GetDefault()->AddObject(pCont1);

  EGLabel *pLabel = new EGLabel(pCont1);
  pLabel->SetFormatText("No rollover");

  for(uint32_t i = 0; i < 10; i++){
    EGButton *pButton = new EGButton(pCont1);
    pButton->SetSize(70, EG_SIZE_CONTENT);
    pButton->AddFlag(EG_OBJ_FLAG_CHECKABLE);
    pGroup->RemoveObject(pButton);   // Not needed, we use the gridnav instead

    pLabel = new EGLabel(pButton);
    pLabel->SetFormatText("%d", i);
    pLabel->Center();
  }

    // Create a second container with rollover grid nav mode.
    EGObject *pCont2 = new EGObject(pScreen);
    EGGridNav::Install(pCont2, EG_GRIDNAV_CTRL_ROLLOVER);
    pCont2->SetStyleBackColor(EG_LightPalette(EG_PALETTE_BLUE, 5), EG_STATE_FOCUSED);
    pCont2->SetSize(EG_PCT(50), EG_PCT(100));
    pCont2->Align(EG_ALIGN_RIGHT_MID, 0, 0);

    pLabel = new EGLabel(pCont2);
    pLabel->SetWidth(EG_PCT(100));
    pLabel->SetFormatText("Rollover\nUse tab to focus the other container");

    // Only the container needs to be in a group
    pGroup->AddObject(pCont2);

    // Add and place some children manually
    EGEdit *pEdit = new EGEdit(pCont2);
    pEdit->SetSize(EG_PCT(100), 80);
    pEdit->SetPosition(0, 80);
    pGroup->RemoveObject(pEdit);   // Not needed, we use the gridnav instead

    EGCheckbox *pCheck = new EGCheckbox(pCont2);
    pCheck->SetPosition(0, 170);
    pGroup->RemoveObject(pCheck);   // Not needed, we use the gridnav instead

    EGSwitch *pSwitch = new EGSwitch(pCont2);
    pSwitch->SetPosition(0, 200);
    pGroup->RemoveObject(pSwitch);   // Not needed, we use the gridnav instead

    pSwitch = new EGSwitch(pCont2);
    pSwitch->SetPosition(EG_PCT(50), 200);
    pGroup->RemoveObject(pSwitch);   // Not needed, we use the gridnav instead
}

#endif


