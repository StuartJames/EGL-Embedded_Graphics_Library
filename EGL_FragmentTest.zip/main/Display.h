/*
 *              Copyright (c) 2020-2021 HydraSystems.
 *
 *  This software is copyrighted by and is the sole property of
 *  HydraSystems.  All rights, title, ownership, or other interests
 *  in the software remain the property of HydraSystems.
 *  This software may only be used in accordance with the corresponding
 *  license agreement.  Any unauthorised use, duplication, transmission,
 *  distribution, or disclosure of this software is expressly forbidden.
 *
 *  This Copyright notice may not be removed or modified without prior
 *  written consent of HydraSystems.
 *
 *  HydraSystems, reserves the right to modify this software without
 *  notice.
 *
 * =====================================================================
 *
 * Edit     Date     Version       Edit Description
 * ====  ==========  ======= ===========================================
 * SJ    2025/04/18   1.a.1   Original LEGLDemo
 *
 */

#pragma once

#include "EGLTest.h"

/////////////////////////////////////////////////////////////////////////////////////

#define LVGL_TICK_PERIOD_MS  1000

/////////////////////////////////////////////////////////////////////////////////////

typedef enum : uint8_t{
	DISP_SMALL,
	DISP_MEDIUM,
	DISP_LARGE,
} DispSize_e;

/////////////////////////////////////////////////////////////////////////////////////

void SetBacklight(EGEvent *pEvent);
void DisplayThread(void *pArg);

